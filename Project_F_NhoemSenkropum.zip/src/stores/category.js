import {defineStore} from 'pinia';
import {ref} from 'vue';
import api from '@/API/http';
export const useCategoryStore = defineStore('category',() => {
    let categories = ref([])

    async function fetchCategories(){
        let res = await api.get('/categories');
        categories.value = res.data.data.items;
        console.log(res);


    }
    return { categories, fetchCategories};
})
