<template>
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm px-3">
        <div class="container-fluid ">
            <span class="navbar-brand fw-bold">📰 Article Dashboard</span>
            <div class="d-flex align-items-center justify-content-center gap-3">
            </div>
        </div>
    </nav>
    <div class="d-flex ">
            <Sidebar />
        <div class="flex-grow-1 content">
            <div class=" d-flex justify-content-between mb-4">
                <h3 class="fw-bold ">Article Page</h3>
                <router-link to="/createArticle" class="btn btn-primary rounded-pill">
                     New Article
                </router-link>
            </div>
            <div class="row g-3 border-4  rounded-1 shadow-sm mt-2 d-flex p-4">
                <BaseTable :rows="articleStore.ownedArticles" :columns="columns"  @delete="handleDelete" @edit="gotoEdit"> 
                    <template
                        #col-thumbnail="{ value }">
                        <img :src="value" class="rounded-circle" width="100px table-thumbnail" height="100px" />
                    </template>
                    <template #col-category="value">
                        {{ value.row.category.name }}
                    </template>
                </BaseTable>
                <!-- <BasePagination 
                :totalPages="articleStore.pagination.totalPages";
                :current = "articleStore.pagination.currentPage " 
                @update:page="handleNextPage"
                
                /> -->
            </div>

        </div>
    </div>



</template>
<script setup>
import Sidebar from '@/components/layout/Sidebar.vue';
import {ref} from 'vue';
import { onMounted } from 'vue';
import { useArticleStore } from '@/stores/article';
import BaseTable from '@/components/UI/BaseTable.vue';
import api from '@/API/http.js'
import { useRouter } from 'vue-router';
import BasePagination from '@/components/UI/BasePagination.vue';
const router = useRouter();

let perPage = ref(3)

let articleStore = useArticleStore();
let columns = [
    { key: 'id', label: 'ID' },
    { key: 'title', label: 'Title' },
    { key: 'thumbnail', label: 'Thumbnail' },
    { key: 'content', label: 'Content' },
    {key: 'category', label: 'Category' },
]
onMounted(async () => {
    await articleStore.fetchOwnedArticles(1, perPage.value);
});
const handleNextPage = async(page) => {
        await articleStore.fetchOwnedArticles(page, perPage.value);


}

 async function handleDelete(id) {
    alert('Delete article with ID: ' + id);
    let res = await api.delete('/articles/' + id);
    await articleStore.fetchOwnedArticles();
    
}   
const gotoEdit = (id) => {
    router.push(`/editArticle/${id}`)
};
</script>
<style scoped>
</style>