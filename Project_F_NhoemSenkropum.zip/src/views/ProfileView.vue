<template>
  <Navbar />
  <div class="d-flex">
    <Sidebar />

    <div class="profile-card p-5 rounded-4 shadow-sm bg-white">

      <!-- Cover -->
      <div class="cover-img mb-4 rounded-4 overflow-hidden">
        <img
          src="https://i.pinimg.com/736x/ba/e6/28/bae62830516e28be33c4b5e9d281c107.jpg"
          class="w-100"
          style="height: 200px; object-fit: cover;"
        />
      </div>

      <!-- Avatar & name -->
      <div class="d-flex align-items-center gap-3 mb-3">
        <div class="profile-pic-wrapper position-relative">
          <img
            :src="avatar"
            class="rounded-circle border border-white shadow-sm"
            width="100"
            height="100"
          />

          <button
            class="camera-btn position-absolute bottom-0 end-0 bg-primary rounded-circle border-0 p-2"
          >
          
            <i class="bi bi-camera-fill text-white"></i>
          </button>
        </div>

        <div>
          <!-- ❌ your template had many syntax errors here -->
          <h2 class="fw-bold mb-1">
            {{ firstName }} {{ lastName }}
          </h2>
          <div class="text-muted">
            User ID :  {{ id }}
          </div>
        </div>
      </div>

      <!-- Actions -->
      <div class="d-flex gap-2 mb-3">
        <router-link to="/editProfile" class="btn btn-outline-dark">Edit Profile</router-link>
        <button class="btn btn-outline-secondary">Copy link</button>
      </div>

      <!-- Info -->
      <div class=" align-items-center gap-3 mb-3 flex-wrap">
        <div class="text-muted">
          <i class="bi bi-geo-alt me-1"></i> {{ location }}
        </div>
              <div class="about-text">
        <p>About User </p>
      </div>

        <div class="text-success">
          <i class="bi bi-globe me-1"></i> Email :  {{ email }}
        </div><br>
        <div class="text-purple">
          <i class="bi bi-clock-history me-1"></i>
          Joined : {{ joinedAt }}
        </div>
      </div>

      <!-- About -->

    </div>
  </div>
</template>

<script setup>
import { computed, onMounted } from 'vue'
import Navbar from '@/components/layout/Navbar.vue'
import Sidebar from '@/components/layout/Sidebar.vue'
import { useAuthStore } from '@/stores/Auth'
const auth = useAuthStore()

onMounted(async () => {
  if (!auth.user) {
    await auth.profile()
  }
})

const user = computed(() => auth.user || {})

const avatar = computed(() =>
  user.value.avatar || 'https://i.pravatar.cc/150'
)

const firstName = computed(() => user.value.firstName || '')
const lastName  = computed(() => user.value.lastName || '')
const email     = computed(() => user.value.email || '')
const id   = computed(() => user.value.id || '-')

const joinedAt = computed(() => {
  if (!user.value.registeredAt) return '-'
  return new Date(user.value.registeredAt)
})
</script>

<style scoped>
.profile-card {
  max-width: 700px;
  margin: auto;
}

.profile-pic-wrapper {
  width: 100px;
  height: 100px;
}

.camera-btn {
  width: 30px;
  height: 30px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.text-purple {
  color: #a67ff3;
}
</style>
