<template>
  <Navbar />

  <div class="d-flex">
    <Sidebar />

    <div class="flex-grow-1 content">
      <div class="row justify-content-between align-items-center mb-4">
        <h3 class="fw-bold col">Category Page</h3>
        <div class="col-auto">
          <button class="btn btn-success">New Category</button>
        </div>
      </div>

      <div class="row g-3 border-4 rounded-1 shadow-sm mt-2 p-4">
        <BaseTable
          :rows="categoriesStore.categories"
          :columns="columns"
          @delete="handleDelete"
          @edit="gotoEdit"
        />

        <!-- <BasePagination
          :totalPages="categoriesStore.pagination.totalPages"
          :current="categoriesStore.pagination.currentPage"
          @update:page="handleNextPage"
        /> -->
        <BasePagination/>
       
      </div>
    </div>
  </div>
</template>
<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'

import Navbar from '@/components/layout/Navbar.vue'
import Sidebar from '@/components/layout/Sidebar.vue'
import BaseTable from '@/components/UI/BaseTable.vue'
import BasePagination from '@/components/UI/BasePagination.vue'
import api from '@/API/http.js'
import { useCategoryStore } from '@/stores/category'

const router = useRouter()
const categoriesStore = useCategoryStore()

const perPage = ref(3)

const columns = [
  { key: 'id', label: 'ID' },
  { key: 'name', label: 'Name' },
]

onMounted(async () => {
  await categoriesStore.fetchCategories(1, perPage.value)
})

const handleNextPage = async (page) => {
  await categoriesStore.fetchCategories(page, perPage.value)
}
const handleDelete = async (id) => {
  if (!confirm('Are you sure you want to delete this category?')) return

  await api.delete(`/categories/${id}`)
  await categoriesStore.fetchCategories(1, perPage.value)
}


const gotoEdit = (id) => {
  router.push(`/editCategories/${id}`)
}

</script>