<template>
    <div class="background-container d-flex justify-content-center align-items-center">
        <div class="login-card p-4 shadow">

            <!-- Header -->
            <div class="d-flex align-items-center justify-content-center gap-2 mb-4">
            </div>

            <!-- Form -->
            <div class="glass-form p-4 text-center">
                <h4 class="fw-bold text-primary">Welcome Back</h4>
                <p class="text-muted small mb-4">Please log in to continue.</p>

                <form @submit.prevent="handleLogin">
                    <!-- Email -->
                    <div class="mb-3 position-relative">
                        <input type="text" class="form-control rounded-pill" placeholder="Email"
                            v-model="email" />
                            <div><p v-if="err.email" class="text-danger small ms-3 text-start">{{ err.email }}</p></div>
                    </div>

                    <!-- Password -->
                    <div class="mb-3 position-relative">
                        <input type="password" class="form-control rounded-pill" placeholder="Password" 
                            v-model="password" />
                            <div v-if="err.password"><p class="text-danger small ms-3 text-start">{{ err.password }}</p></div>
                    </div>

                    <!-- Options -->
                    <div class="d-flex justify-content-between align-items-center mb-3 small">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" checked />
                            <label class="form-check-label">Remember me</label>
                        </div>
                        <a href="#" class="text-decoration-none">Forgot password?</a>
                    </div>

                    <!-- Button -->
                    <button :disabled="isLoading" class="btn btn-primary w-100 rounded-pill py-2 fw-bold">
                        <div v-if="isLoading" class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                        <div v-else>
                            Log In
                        </div>
                    </button>
                </form>

                <!-- Signup -->
                <p class="small mt-3">
                    Don’t have an account?
                    <router-link to="/register" class="fw-bold text-decoration-none">Sign Up</router-link>
                </p>

            </div>
        </div>
    </div>

</template>
<script setup>
import router from '@/router/index.js'
import { reactive, ref } from 'vue';
import { useAuthStore } from '@/stores/Auth'
import { isEmail, required , validate } from '@/utils/Validate.js';
import { toast } from 'vue3-toastify';
import { nofity } from '@/utils/toast';
let email = ref('')
let password = ref('')
let auth = useAuthStore()
let err = reactive({
    email: '',
    password: ''
})
let isLoading = ref(false);
function validator() {
    err.email = validate(email.value, [
        (v) =>  required(v, "this email is required"),
        (v) => isEmail(v, "is not email")
    ])

    err.password = required(password.value, 'Password is required');
    return !err.email && !err.password;

}

async function handleLogin() {
    if(!validator()) return;
        isLoading.value = true;
    try{
            await auth.login(email.value, password.value);
            nofity.success('login Successfully', '/');

                
    } catch (e) {
        toast.error(e.data.message)
        isLoading.value = false;


    } 
    finally{
    }
}
</script>
<style scoped>
body {
    min-height: 100vh;
    background: linear-gradient(135deg, #a1c4fd, #c2e9fb);
}

.background-container {
    min-height: 100vh;
    background: radial-gradient(circle at top left, #8191f1, transparent),
        radial-gradient(circle at bottom right, #f1a7f1, transparent);
}

.login-card {
    width: 380px;
    background: rgba(255, 255, 255, 0.25);
    backdrop-filter: blur(15px);
    border-radius: 30px;
    border: 1px solid rgba(255, 255, 255, 0.3);
}

.glass-form {
    background: rgba(255, 255, 255, 0.7);
    border-radius: 25px;
}

.input-icon {
    position: absolute;
    top: 50%;
    left: 15px;
    transform: translateY(-50%);
    color: #4a69bd;
}

.form-control {
    padding-left: 45px;
}

.btn-primary {
    background: linear-gradient(to right, #4bc0c8, #6a11cb);
    border: none;
}
</style>