import axios from "axios";
import { useAuthStore } from "@/stores/Auth";

const api = axios.create({
    baseURL: 'http://blogs2.csm.linkpc.net/api/v1'
})
api.interceptors.request.use((config)=>{
    let auth = useAuthStore();
    if(auth.isLoggedIn){
        config.headers.Authorization = `Bearer ${auth.token}`;
    }
    return config;
})

export default api;